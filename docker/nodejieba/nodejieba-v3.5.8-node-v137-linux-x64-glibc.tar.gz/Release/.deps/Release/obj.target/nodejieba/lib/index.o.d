cmd_Release/obj.target/nodejieba/lib/index.o := g++ -o Release/obj.target/nodejieba/lib/index.o ../lib/index.cpp '-DNODE_GYP_MODULE_NAME=nodejieba' '-DUSING_UV_SHARED=1' '-DUSING_V8_SHARED=1' '-DV8_DEPRECATION_WARNINGS=1' '-D_GLIBCXX_USE_CXX11_ABI=1' '-D_FILE_OFFSET_BITS=64' '-D_LARGEFILE_SOURCE' '-D__STDC_FORMAT_MACROS' '-DOPENSSL_NO_PINSHARED' '-DOPENSSL_THREADS' '-DBUILDING_NODE_EXTENSION' -I/home/runner/.cache/node-gyp/24.14.0/include/node -I/home/runner/.cache/node-gyp/24.14.0/src -I/home/runner/.cache/node-gyp/24.14.0/deps/openssl/config -I/home/runner/.cache/node-gyp/24.14.0/deps/openssl/openssl/include -I/home/runner/.cache/node-gyp/24.14.0/deps/uv/include -I/home/runner/.cache/node-gyp/24.14.0/deps/zlib -I/home/runner/.cache/node-gyp/24.14.0/deps/v8/include -I../node_modules/node-addon-api -I../submodules/cppjieba/include -I../submodules/cppjieba/deps/limonp/include  -fPIC -pthread -Wall -Wextra -Wno-unused-parameter -DLOGGING_LEVEL=LL_WARNING -m64 -O3 -fno-omit-frame-pointer -fno-rtti -fno-strict-aliasing -std=gnu++20 -MMD -MF ./Release/.deps/Release/obj.target/nodejieba/lib/index.o.d.raw   -c
Release/obj.target/nodejieba/lib/index.o: ../lib/index.cpp \
 ../lib/nodejieba.h ../node_modules/node-addon-api/napi.h \
 /home/runner/.cache/node-gyp/24.14.0/include/node/node_api.h \
 /home/runner/.cache/node-gyp/24.14.0/include/node/js_native_api.h \
 /home/runner/.cache/node-gyp/24.14.0/include/node/js_native_api_types.h \
 /home/runner/.cache/node-gyp/24.14.0/include/node/node_api_types.h \
 ../node_modules/node-addon-api/napi-inl.h \
 ../node_modules/node-addon-api/napi-inl.deprecated.h
../lib/index.cpp:
../lib/nodejieba.h:
../node_modules/node-addon-api/napi.h:
/home/runner/.cache/node-gyp/24.14.0/include/node/node_api.h:
/home/runner/.cache/node-gyp/24.14.0/include/node/js_native_api.h:
/home/runner/.cache/node-gyp/24.14.0/include/node/js_native_api_types.h:
/home/runner/.cache/node-gyp/24.14.0/include/node/node_api_types.h:
../node_modules/node-addon-api/napi-inl.h:
../node_modules/node-addon-api/napi-inl.deprecated.h:
